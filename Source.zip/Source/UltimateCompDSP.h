/*
  ==============================================================================
    UltimateCompDSP.h
    Port of Ultimate Mix Bus Compressor v3.20
    - Fixed Latency Reporting (Constant)
    - True Compressor Auto-Gain (Hybrid RMS)
    - Fixed Saturator Auto-Gain (Proper Staging)
    - Fixed Feedback Detector Tap
    - FIXED: Member variable naming in Audition Block
    - UPDATED: Removed SC->Sat, Extended Filter Ranges
    - ADDED: Mojo Parallel Processing Chain
    - ADDED: Global Input/Output and Variable Mojo Mix
    - FIX [2026-01-09]: Mojo Compressor moved INSIDE Oversampling to fix aliasing
  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include <vector>
#include <cmath>
#include <algorithm>
#include "SimpleBiquad.h"

class UltimateCompDSP
{
public:
    UltimateCompDSP() { resetState(); }

    // ==============================================================================
    // PUBLIC PARAMETERS
    // ==============================================================================

    // --- GLOBAL ---
    int   p_signal_flow = 0; // 0 = Comp > Sat, 1 = Sat > Comp
    float p_global_in = 0.0f;  // Global Input Gain (dB)

    // --- MODULE BYPASS STATES ---
    bool p_active_dyn = true;
    bool p_active_det = true;
    bool p_active_crest = true;
    bool p_active_tf = true;
    bool p_active_sat = true;
    bool p_active_eq = true;

    // --- MOJO (Parallel Analog Chain) ---
    bool p_mojo = false;
    float p_mojo_mix = 50.0f; // Mojo Mix %
    float p_mojo_balance = 0.0f; // NOW ACTS AS LEVEL (dB)
    float p_mojo_thresh_db = -38.0f; // Stuff Threshold (dB)

    // --- SIDECHAIN EXPERT ---
    int  p_sc_input_mode = 0; // 0 = Internal, 1 = External
    bool p_sc_to_comp = true;
    int  p_ms_mode = 0;
    float p_ms_balance_db = 0.0f; // NEW: M/S balance for cross modes

    // --- DYNAMICS ---
    float p_comp_input = 0.0f;
    bool  p_comp_mirror = false;

    float p_thresh = -20.0f;
    float p_ratio = 4.0f;
    float p_knee = 6.0f;
    float p_att_ms = 10.0f;
    float p_rel_ms = 100.0f;
    int   p_auto_rel = 0;

    int   p_comp_autogain_mode = 0; // 0=Off, 1=Partial, 2=Full

    bool  p_turbo_att = false;
    bool  p_turbo_rel = false;

    // --- AUTO CREST ---
    int   p_ctrl_mode = 0;
    float p_crest_target = 12.0f;
    float p_crest_speed = 400.0f;

    // --- DETECTOR ---
    int   p_thrust_mode = 0;
    float p_det_rms = 0.0f;
    float p_stereo_link = 100.0f;
    float p_sc_hp_freq = 20.0f;
    float p_sc_lp_freq = 20000.0f;
    float p_fb_blend = 0.0f;
    float p_sc_level_db = 0.0f; // Sidechain Level Trim (dB)
    bool  p_sc_audition = false; // Monitor detector feed

    // --- SIDECHAIN TRANSIENT DESIGNER (Detector Conditioning) ---
    float p_sc_td_amt = 0.0f;   // -100..100 (transient emphasis)
    float p_sc_td_ms = 0.0f;   // 0..100 (0=Mid focus, 100=Side focus)

    // --- TRANSIENT PRIORITY ---
    int   p_tp_mode = 0;
    float p_tp_amount = 50.0f;
    float p_tp_thresh_raise = 12.0f;

    // --- FLUX COUPLED ---
    int   p_flux_mode = 0;
    float p_flux_amount = 30.0f;

    // --- SATURATION ---
    int   p_sat_mode = 0;
    float p_sat_pre_gain = 0.0f;
    bool  p_sat_mirror = false;
    float p_sat_drive = 0.0f;
    float p_sat_trim = 0.0f;
    float p_sat_tone = 0.0f;
    float p_sat_tone_freq = 5500.0f;
    float p_sat_mix = 100.0f;
    int   p_sat_autogain_mode = 1;

    // --- HARMONIC BRIGHTNESS ---
    float p_harm_bright = 0.0f;
    float p_harm_freq = 4500.0f;

    // --- COLOR EQ (Pultec-style low-end) ---
    float p_girth = 0.0f;        // dB
    int   p_girth_freq_sel = 2;  // 0=20,1=30,2=60,3=100

    // --- OUTPUT ---
    float p_makeup = 0.0f;
    float p_dry_wet = 100.0f;
    float p_out_trim = 0.0f;

    // ==============================================================================
    // GETTERS
    // ==============================================================================
    float getGainReductiondB() const { return (float)env; }
    float getFluxSaturation() const { return (float)flux_env; }
    float getCrestAmt() const { return (float)cf_amt; }

    // Constant latency reporting
    double getLatency() const { return (double)os_latency_samples; }

    // ==============================================================================
    // LIFECYCLE
    // ==============================================================================

    void prepare(double sampleRate, int maxBlockSamples)
    {
        s_rate = (sampleRate > 1.0 ? sampleRate : 48000.0);
        max_block = std::max(1, maxBlockSamples);

        os_stages = 2;
        os_factor = 1 << os_stages;

        dry_buf.setSize(2, max_block, false, false, true);
        wet_buf.setSize(2, max_block, false, false, true);
        sc_internal_buf.setSize(2, max_block, false, false, true);
        sat_clean_buf.setSize(2, max_block, false, false, true);
        sat_proc_buf.setSize(2, max_block, false, false, true);
        mojo_buf.setSize(2, max_block, false, false, true);

        mojo_os_stages = 0;
        mojo_os_factor = 1;
        mojo_os.reset();

        os = std::make_unique<juce::dsp::Oversampling<float>>(
            2, os_stages, juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR, true);
        os->initProcessing((size_t)max_block);

        os_latency_samples = (int)os->getLatencyInSamples();

        juce::dsp::ProcessSpec spec;
        spec.sampleRate = s_rate;
        spec.maximumBlockSize = (juce::uint32)max_block;
        spec.numChannels = 2;

        satInternalDelay.prepare(spec);
        satInternalDelay.reset();

        dryDelayLine.prepare(spec);
        wetDelayLine.prepare(spec);
        dryDelayLine.reset();
        wetDelayLine.reset();

        // FIX: Set Delay Line limits ONCE, cleanly
        dryDelayLine.setDelay((float)os_latency_samples);
        wetDelayLine.setDelay((float)os_latency_samples);

        rms_window_max = juce::jmax(1, (int)std::ceil(0.300 * s_rate));
        rms_ring_l.assign((size_t)rms_window_max, 0.0);
        rms_ring_r.assign((size_t)rms_window_max, 0.0);
        rms_window = 1;
        rms_pos = 0;
        rms_sum_l = rms_sum_r = 0.0;

        resetState();
        updateParameters();
    }

    void reset() noexcept
    {
        if (os) os->reset();
        satInternalDelay.reset();
        dryDelayLine.reset();
        wetDelayLine.reset();
        resetState();
    }

    void resetState()
    {
        sc_hp_l.reset(); sc_hp_r.reset(); sc_hp_l_2.reset(); sc_hp_r_2.reset();
        sc_lp_l.reset(); sc_lp_r.reset(); sc_lp_l_2.reset(); sc_lp_r_2.reset();
        sat_tone_l.reset(); sat_tone_r.reset();
        girth_bump_l.reset(); girth_bump_r.reset(); girth_dip_l.reset(); girth_dip_r.reset();
        harm_pre_l.reset(); harm_pre_r.reset(); harm_post_l.reset(); harm_post_r.reset();
        iron_voicing_l.reset(); iron_voicing_r.reset();
        steel_low_l.reset(); steel_low_r.reset(); steel_high_l.reset(); steel_high_r.reset();

        mojo_hp_l.reset(); mojo_hp_r.reset();
        mojo_low_shelf_l.reset(); mojo_low_shelf_r.reset();
        mojo_dip_l.reset(); mojo_dip_r.reset();
        mojo_hi_shelf_l.reset(); mojo_hi_shelf_r.reset();
        mojo_lp_l.reset(); mojo_lp_r.reset();

        mojo_on_sm = 0.0;
        mojo_prev_on = false;
        mojo_scale_sm = 1.0;
        mojo_env = 0.0;
        mojo_mix_sm = 0.5;

        mojo_dc_x1_l = mojo_dc_y1_l = 0.0;
        mojo_dc_x1_r = mojo_dc_y1_r = 0.0;

        if (os) os->reset();
        satInternalDelay.reset();
        dryDelayLine.reset();
        wetDelayLine.reset();

        steel_phi_l = steel_phi_r = 0.0;
        steel_prev_x_l = steel_prev_x_r = 0.0;
        sat_agc_gain_sm = 1.0;
        sc_level_sm = 1.0;
        ms_bal_sm = 1.0;

        global_in_sm = 1.0;

        sc_td_amt_sm = 0.0;
        sc_td_ms_sm = 0.0;
        sc_td_fast_mid = sc_td_slow_mid = 0.0;
        sc_td_fast_side = sc_td_slow_side = 0.0;

        fb_prev_l = fb_prev_r = 0.0;
        det_env = 0.0;
        env = 0.0;
        env_l = env_r = 0.0;
        env_fast = env_slow = 0.0;
        env_fast_l = env_fast_r = 0.0;
        env_slow_l = env_slow_r = 0.0;
        cf_peak_env = 0.0; cf_rms_sum = 0.0; cf_amt = 0.0; cf_ratio_mix = 0.0;
        flux_env = 0.0;

        comp_agc_gain_sm = 1.0;
        sat_agc_gain_sm = 1.0;

        thresh_sm = p_thresh;
        ratio_sm = std::max(1.0, (double)p_ratio);
        knee_sm = std::max(0.0, (double)p_knee);
        makeup_lin_sm = dbToLin((double)p_makeup);
        comp_in_sm = dbToLin((double)p_comp_input);

        sat_pre_lin_sm = dbToLin((double)p_sat_pre_gain);
        sat_drive_lin_sm = dbToLin((double)p_sat_drive);
        sat_trim_lin_sm = dbToLin((double)p_sat_trim);
        sat_mix_sm = juce::jlimit(0.0, 1.0, (double)p_sat_mix / 100.0);

        last_sat_mode = -1;
        last_ctrl_mode = -1;

        topologyRamp = 1.0;
        topologyInc = 0.0;
        prevTopoSatEq = (p_active_sat || p_active_eq);
        prevTopoFlow = p_signal_flow;
        prevTopoAudition = p_sc_audition;
        prevTopoMsMode = p_ms_mode;
        prevTopoScMode = p_sc_input_mode;
        prevTopoScToComp = p_sc_to_comp;

        c_s_rate = -1.0; // Force param cache reload
    }

    void armTopologyFade() noexcept
    {
        const int maxFade = juce::jmax(16, max_block);
        const int fadeSamples = juce::jlimit(16, maxFade, (int)std::round(0.010 * s_rate)); // 10 ms
        topologyRamp = 0.0;
        topologyInc = 1.0 / (double)fadeSamples;
    }

    void handleTopologyChangeIfNeeded() noexcept
    {
        const bool satEq = (p_active_sat || p_active_eq);
        const bool audition = p_sc_audition;
        const int flow = p_signal_flow;
        const int msMode = p_ms_mode;
        const int scMode = p_sc_input_mode;
        const bool scToComp = p_sc_to_comp;

        const bool changed =
            (satEq != prevTopoSatEq) ||
            (audition != prevTopoAudition) ||
            (flow != prevTopoFlow) ||
            (msMode != prevTopoMsMode) ||
            (scMode != prevTopoScMode) ||
            (scToComp != prevTopoScToComp);

        if (!changed) return;

        if (os) os->reset();
        satInternalDelay.reset();

        // FIX A: Removed dryDelayLine and wetDelayLine .reset() and .setDelay() calls 
        // to prevent click/hole artifacts. They act as continuous compensators.

        if ((audition != prevTopoAudition) || (msMode != prevTopoMsMode) || (scMode != prevTopoScMode) || (scToComp != prevTopoScToComp))
            resetDetectorConditioningState();

        armTopologyFade();

        prevTopoSatEq = satEq;
        prevTopoAudition = audition;
        prevTopoFlow = flow;
        prevTopoMsMode = msMode;
        prevTopoScMode = scMode;
        prevTopoScToComp = scToComp;
    }

    void process(juce::AudioBuffer<float>& buffer, const juce::AudioBuffer<float>* sidechainBuffer = nullptr)
    {
        juce::ScopedNoDenormals noDenormals;

        const int totalSamples = buffer.getNumSamples();
        if (totalSamples <= 0) return;

        const int chunkSize = juce::jmax(1, max_block);

        handleTopologyChangeIfNeeded();

        int offset = 0;
        while (offset < totalSamples)
        {
            const int nSamp = juce::jmin(chunkSize, totalSamples - offset);

            smooth_alpha_block = std::exp(-(double)nSamp / (0.020 * s_rate));
            updateParameters();

            global_in_sm = smooth1p(global_in_sm, global_in_target, smooth_alpha_block);
            mojo_mix_sm = smooth1p(mojo_mix_sm, mojo_mix_target, smooth_alpha_block);

            // RAW POINTER ITERATION FOR AUDIO THREAD SAFETY
            const float* inL = buffer.getReadPointer(0) + offset;
            const float* inR = (buffer.getNumChannels() > 1) ? (buffer.getReadPointer(1) + offset) : inL;

            float* dL = dry_buf.getWritePointer(0);
            float* dR = dry_buf.getWritePointer(1);
            float* wL = wet_buf.getWritePointer(0);
            float* wR = wet_buf.getWritePointer(1);

            const float gIn = (float)global_in_sm;

            for (int i = 0; i < nSamp; ++i) {
                float l = inL[i] * gIn;
                float r = inR[i] * gIn;
                dL[i] = l;
                dR[i] = r;
                wL[i] = l;
                wR[i] = r;
            }

            // FIX: Protective sidechain bounds clamp
            int sc_samples_available = sidechainBuffer ? sidechainBuffer->getNumSamples() : 0;
            if (p_sc_input_mode == 1 && sidechainBuffer != nullptr && sidechainBuffer->getNumChannels() > 0 && sc_samples_available > 0)
            {
                const float* scL = sidechainBuffer->getReadPointer(0);
                const float* scR = (sidechainBuffer->getNumChannels() > 1) ? sidechainBuffer->getReadPointer(1) : scL;

                float* sciL = sc_internal_buf.getWritePointer(0);
                float* sciR = sc_internal_buf.getWritePointer(1);

                for (int i = 0; i < nSamp; ++i) {
                    int readIdx = offset + i;
                    if (readIdx < sc_samples_available) {
                        sciL[i] = scL[readIdx];
                        sciR[i] = scR[readIdx];
                    }
                    else {
                        sciL[i] = 0.0f;
                        sciR[i] = 0.0f;
                    }
                }
            }
            else
            {
                float* sciL = sc_internal_buf.getWritePointer(0);
                float* sciR = sc_internal_buf.getWritePointer(1);
                for (int i = 0; i < nSamp; ++i) {
                    sciL[i] = dL[i];
                    sciR[i] = dR[i];
                }
            }

            if (p_sc_audition)
            {
                processAuditionBlock(wet_buf);

                if (p_active_sat && os)
                {
                    auto subBlock = juce::dsp::AudioBlock<float>(wet_buf).getSubBlock(0, (size_t)nSamp);
                    auto osBlock = os->processSamplesUp(subBlock);
                    (void)osBlock;
                    os->processSamplesDown(subBlock);
                }
            }
            else
            {
                if (p_signal_flow == 1)
                {
                    processSaturationBlock(wet_buf, nSamp);
                    processCompressorBlock(wet_buf);
                }
                else
                {
                    processCompressorBlock(wet_buf);
                    processSaturationBlock(wet_buf, nSamp);
                }
            }

            // TRUE BIT-TRANSPARENT DELAY LINE (REPLACES os_dry)
            if (os_latency_samples > 0)
            {
                auto dryBlock = juce::dsp::AudioBlock<float>(dry_buf).getSubBlock(0, (size_t)nSamp);
                juce::dsp::ProcessContextReplacing<float> dryCtx(dryBlock);
                dryDelayLine.process(dryCtx);

                if (!(p_active_sat && os))
                {
                    auto wetBlock = juce::dsp::AudioBlock<float>(wet_buf).getSubBlock(0, (size_t)nSamp);
                    juce::dsp::ProcessContextReplacing<float> wetCtx(wetBlock);
                    wetDelayLine.process(wetCtx);
                }
            }

            if (mojo_on_sm > 0.001)
            {
                processMojoBlock(dry_buf, nSamp);
            }

            const double dw_target = p_sc_audition ? 1.0 : juce::jlimit(0.0, 1.0, (double)p_dry_wet / 100.0);
            drywet_sm = smooth1p(drywet_sm, dw_target, smooth_alpha_block);

            const double final_gain_target = dbToLin((double)p_out_trim);
            out_lin_sm = smooth1p(out_lin_sm, final_gain_target, smooth_alpha_block);
            const float finalGain = (float)out_lin_sm;

            float* outL = buffer.getWritePointer(0) + offset;
            float* outR = (buffer.getNumChannels() > 1) ? (buffer.getWritePointer(1) + offset) : nullptr;

            const float* wetL = wet_buf.getReadPointer(0);
            const float* wetR = wet_buf.getReadPointer(1);
            const float* dryLL = dry_buf.getReadPointer(0);
            const float* dryRR = dry_buf.getReadPointer(1);
            const float* mojoL = mojo_buf.getReadPointer(0);
            const float* mojoR = mojo_buf.getReadPointer(1);

            const float mojoMix = (float)(mojo_on_sm * mojo_mix_sm);

            const double mojoLevelTarget = dbToLin((double)p_mojo_balance);
            mojo_level_sm = smooth1p(mojo_level_sm, mojoLevelTarget, smooth_alpha_block);
            const float mojoGain = (float)mojo_level_sm;

            for (int i = 0; i < nSamp; ++i)
            {
                if (topologyRamp < 1.0)
                    topologyRamp = std::min(1.0, topologyRamp + topologyInc);

                const float wm = (float)(drywet_sm * topologyRamp);
                const float dm = 1.0f - wm;

                float sigL = (wetL[i] * wm + dryLL[i] * dm);
                float sigR = (wetR[i] * wm + dryRR[i] * dm);

                if (mojoMix > 0.0f) {
                    sigL += mojoL[i] * mojoMix * mojoGain;
                    sigR += mojoR[i] * mojoMix * mojoGain;
                }

                outL[i] = sigL * finalGain;
                if (outR)
                    outR[i] = sigR * finalGain;
            }

            offset += nSamp;
        }
    }

    void updateParameters()
    {
        // FIX: CPU-saving parameter cache checks
        bool force = false;

        if (s_rate != c_s_rate) {
            c_s_rate = s_rate;
            force = true;

            sc_td_fast_att = std::exp(-1000.0 / (1.0 * s_rate));
            sc_td_fast_rel = std::exp(-1000.0 / (30.0 * s_rate));
            sc_td_slow_att = std::exp(-1000.0 / (25.0 * s_rate));
            sc_td_slow_rel = std::exp(-1000.0 / (250.0 * s_rate));

            smooth_alpha = std::exp(-1.0 / (0.020 * s_rate));
            os_srate = s_rate * (double)os_factor;
            smooth_alpha_os = std::exp(-1.0 / (0.020 * os_srate));

            iron_voicing_l.update_shelf(100.0, 1.0, 0.707, s_rate);
            iron_voicing_r.update_shelf(100.0, 1.0, 0.707, s_rate);
            steel_low_l.update_shelf(40.0, 1.5, 0.707, s_rate);
            steel_low_r.update_shelf(40.0, 1.5, 0.707, s_rate);
            steel_high_l.update_lpf(9000.0, 0.707, s_rate);
            steel_high_r.update_lpf(9000.0, 0.707, s_rate);

            double mojoRate = s_rate;
            mojo_hp_l.update_hpf(20.0, 0.707, mojoRate);
            mojo_hp_r.update_hpf(20.0, 0.707, mojoRate);
            mojo_low_shelf_l.update_low_shelf(80.0, 2.0, 0.9, mojoRate);
            mojo_low_shelf_r.update_low_shelf(80.0, 2.0, 0.9, mojoRate);
            mojo_dip_l.update_peak(320.0, -1.5, 1.5, mojoRate);
            mojo_dip_r.update_peak(320.0, -1.5, 1.5, mojoRate);
            mojo_hi_shelf_l.update_shelf(8000.0, 1.5, 0.707, mojoRate);
            mojo_hi_shelf_r.update_shelf(8000.0, 1.5, 0.707, mojoRate);
            mojo_lp_l.update_lpf(18000.0, 0.707, s_rate);
            mojo_lp_r.update_lpf(18000.0, 0.707, s_rate);

            if (os_srate > 0.0) {
                steel_dt = 1.0 / os_srate;
                steel_dy_gain = os_srate;
                const double leak_hz = 6.0;
                steel_leak_coeff = std::exp(-2.0 * juce::MathConstants<double>::pi * leak_hz / os_srate);
            }
        }

        if (force || p_att_ms != c_att_ms || p_turbo_att != c_turbo_att || p_rel_ms != c_rel_ms || p_turbo_rel != c_turbo_rel) {
            c_att_ms = p_att_ms; c_turbo_att = p_turbo_att; c_rel_ms = p_rel_ms; c_turbo_rel = p_turbo_rel;

            const double attMul = (p_turbo_att ? 0.1 : 1.0);
            const double relMul = (p_turbo_rel ? 0.1 : 1.0);
            const double att_ms = std::max(0.05, (double)p_att_ms * attMul);
            const double rel_ms = std::max(1.0, (double)p_rel_ms * relMul);

            att_coeff = std::exp(-1000.0 / (att_ms * s_rate));
            rel_coeff_manual = std::exp(-1000.0 / (rel_ms * s_rate));
            auto_rel_slow = std::exp(-1000.0 / (1200.0 * s_rate));
            auto_rel_fast = std::exp(-1000.0 / (80.0 * s_rate));
        }

        if (force || p_det_rms != c_det_rms) {
            c_det_rms = p_det_rms;
            use_rms = (p_det_rms > 0.0f);
            if (use_rms) {
                const double win_ms = std::max(1.0, (double)p_det_rms);
                const int desired = std::max(1, (int)std::round((win_ms * 0.001) * s_rate));
                const int clamped = std::min(desired, rms_window_max);
                if (clamped != rms_window)
                {
                    rms_window = clamped;
                    rms_pos = 0;
                    rms_sum_l = rms_sum_r = 0.0;
                    std::fill(rms_ring_l.begin(), rms_ring_l.begin() + (size_t)rms_window, 0.0);
                    std::fill(rms_ring_r.begin(), rms_ring_r.begin() + (size_t)rms_window, 0.0);
                }
            }
        }

        stereo_link = juce::jlimit(0.0, 1.0, (double)p_stereo_link / 100.0);
        fb_blend = juce::jlimit(0.0, 1.0, (double)p_fb_blend / 100.0);

        if (force || p_sc_hp_freq != c_sc_hp_freq) {
            c_sc_hp_freq = p_sc_hp_freq;
            sc_hp_l.update_hpf((double)p_sc_hp_freq, 0.707, s_rate);
            sc_hp_r.update_hpf((double)p_sc_hp_freq, 0.707, s_rate);
            sc_hp_l_2.update_hpf((double)p_sc_hp_freq, 0.707, s_rate);
            sc_hp_r_2.update_hpf((double)p_sc_hp_freq, 0.707, s_rate);
        }

        if (force || p_sc_lp_freq != c_sc_lp_freq) {
            c_sc_lp_freq = p_sc_lp_freq;
            sc_lp_l.update_lpf(std::max(40.0, (double)p_sc_lp_freq), 0.707, s_rate);
            sc_lp_r.update_lpf(std::max(40.0, (double)p_sc_lp_freq), 0.707, s_rate);
            sc_lp_l_2.update_lpf(std::max(40.0, (double)p_sc_lp_freq), 0.707, s_rate);
            sc_lp_r_2.update_lpf(std::max(40.0, (double)p_sc_lp_freq), 0.707, s_rate);
        }

        if (force || p_thrust_mode != c_thrust_mode) {
            c_thrust_mode = p_thrust_mode;
            thrust_gain_db = 0.0;
            if (p_thrust_mode == 1) thrust_gain_db = 3.0;
            if (p_thrust_mode == 2) thrust_gain_db = 6.0;
            if (p_thrust_mode > 0) {
                sc_shelf_l.update_shelf(90.0, thrust_gain_db, 0.707, s_rate);
                sc_shelf_r.update_shelf(90.0, thrust_gain_db, 0.707, s_rate);
            }
        }

        crest_target_db = (double)p_crest_target;
        if (force || p_crest_speed != c_crest_speed) {
            c_crest_speed = p_crest_speed;
            crest_speed_ms = std::max(5.0, (double)p_crest_speed);
            crest_coeff = std::exp(-1000.0 / (crest_speed_ms * s_rate));
        }

        tp_enabled = (p_tp_mode != 0);
        tp_amt = juce::jlimit(0.0, 1.0, (double)p_tp_amount / 100.0);
        tp_raise_db = std::max(0.0, (double)p_tp_thresh_raise);

        flux_enabled = (p_flux_mode != 0);
        flux_amt = juce::jlimit(0.0, 1.0, (double)p_flux_amount / 100.0);

        comp_in_target = dbToLin((double)p_comp_input);
        makeup_lin_target = dbToLin((double)p_makeup);
        sc_level_target = dbToLin((double)p_sc_level_db);
        ms_bal_target = dbToLin((double)p_ms_balance_db);

        sc_td_amt_target = juce::jlimit(-1.0, 1.0, (double)p_sc_td_amt / 100.0);
        sc_td_ms_target = juce::jlimit(0.0, 1.0, (double)p_sc_td_ms / 100.0);

        if (force || p_sat_tone != c_sat_tone || p_sat_tone_freq != c_sat_tone_freq) {
            c_sat_tone = p_sat_tone; c_sat_tone_freq = p_sat_tone_freq;
            sat_tone_l.update_shelf((double)p_sat_tone_freq, (double)p_sat_tone, 0.707, s_rate);
            sat_tone_r.update_shelf((double)p_sat_tone_freq, (double)p_sat_tone, 0.707, s_rate);
        }

        if (force || p_girth != c_girth || p_girth_freq_sel != c_girth_freq_sel) {
            c_girth = p_girth; c_girth_freq_sel = p_girth_freq_sel;
            const int idx = juce::jlimit(0, 3, p_girth_freq_sel);
            static const double freqs[4] = { 20.0, 30.0, 60.0, 100.0 };
            static const double dips[4] = { 65.0, 97.5, 195.0, 325.0 };

            const double f0 = freqs[idx];
            const double fd = dips[idx];

            const double bumpQ = 1.0;
            const double dipQ = 0.6;

            const double bumpDb = (double)p_girth;
            const double dipDb = -(double)p_girth * 0.80;
            girth_bump_l.update_low_shelf(f0 * 4.0, bumpDb, bumpQ, s_rate);
            girth_bump_r.update_low_shelf(f0 * 4.0, bumpDb, bumpQ, s_rate);
            girth_dip_l.update_peak(fd, dipDb, dipQ, s_rate);
            girth_dip_r.update_peak(fd, dipDb, dipQ, s_rate);
        }

        if (force || p_harm_bright != c_harm_bright || p_harm_freq != c_harm_freq) {
            c_harm_bright = p_harm_bright; c_harm_freq = p_harm_freq;
            const double hb = (double)p_harm_bright;
            harm_pre_l.update_shelf((double)p_harm_freq, -hb, 0.707, os_srate);
            harm_pre_r.update_shelf((double)p_harm_freq, -hb, 0.707, os_srate);
            harm_post_l.update_shelf((double)p_harm_freq, hb, 0.707, os_srate);
            harm_post_r.update_shelf((double)p_harm_freq, hb, 0.707, os_srate);
        }

        if (p_mojo && !mojo_prev_on) {
            mojo_hp_l.reset(); mojo_hp_r.reset();
            mojo_low_shelf_l.reset(); mojo_low_shelf_r.reset();
            mojo_dip_l.reset(); mojo_dip_r.reset();
            mojo_hi_shelf_l.reset(); mojo_hi_shelf_r.reset();
            mojo_lp_l.reset(); mojo_lp_r.reset();

            mojo_env = 0.0;
            mojo_scale_sm = 0.0;
            mojo_thresh_sm = (double)p_mojo_thresh_db;
            mojo_dc_x1_l = mojo_dc_y1_l = 0.0;
            mojo_dc_x1_r = mojo_dc_y1_r = 0.0;
        }
        mojo_prev_on = p_mojo;

        const double mojo_target = p_mojo ? 1.0 : 0.0;
        mojo_on_sm = smooth1p(mojo_on_sm, mojo_target, smooth_alpha_block);
        mojo_mix_target = juce::jlimit(0.0, 1.0, (double)p_mojo_mix / 100.0);
        mojo_thresh_sm = smooth1p(mojo_thresh_sm, (double)p_mojo_thresh_db, smooth_alpha_block);

        sat_pre_lin_target = dbToLin((double)p_sat_pre_gain);
        sat_drive_lin_target = dbToLin((double)p_sat_drive);
        sat_mix_target = juce::jlimit(0.0, 1.0, (double)p_sat_mix / 100.0);
        sat_trim_lin = dbToLin((double)p_sat_trim);

        global_in_target = dbToLin((double)p_global_in);

        if (p_sat_mode != last_sat_mode) {
            steel_phi_l = steel_phi_r = 0.0;
            steel_prev_x_l = steel_prev_x_r = 0.0;
            sat_agc_gain_sm = 1.0;
            last_sat_mode = p_sat_mode;
        }

        if (p_ctrl_mode != last_ctrl_mode) {
            cf_peak_env = 0.0; cf_rms_sum = 0.0; cf_amt = 0.0; cf_ratio_mix = 0.0;
            last_ctrl_mode = p_ctrl_mode;
        }
    }

private:
    static inline double dbToLin(double db) { return std::pow(10.0, db / 20.0); }
    static inline double linToDb(double lin) { return 20.0 * std::log10(std::max(lin, 1.0e-20)); }
    static inline double smooth1p(double current, double target, double alpha) { return current + (target - current) * (1.0 - alpha); }

    inline double scTdProcessSample(double x, double& fastEnv, double& slowEnv, double amt) noexcept
    {
        const double ax = std::abs(x);

        const double cFast = (ax > fastEnv) ? sc_td_fast_att : sc_td_fast_rel;
        fastEnv = fastEnv * cFast + ax * (1.0 - cFast);

        const double cSlow = (ax > slowEnv) ? sc_td_slow_att : sc_td_slow_rel;
        slowEnv = slowEnv * cSlow + ax * (1.0 - cSlow);

        const double eps = 1.0e-12;
        double ratio = (fastEnv + eps) / (slowEnv + eps);
        ratio = juce::jlimit(0.25, 4.0, ratio);

        const double depth = 2.0;
        double g = std::exp(std::log(ratio) * (amt * depth));
        g = juce::jlimit(0.25, 4.0, g);

        return x * g;
    }

    inline void applySidechainTransientDesigner(double& s_l, double& s_r) noexcept
    {
        const double amt = juce::jlimit(-1.0, 1.0, sc_td_amt_sm);
        if (std::abs(amt) < 1.0e-9)
            return;

        const double blend = juce::jlimit(0.0, 1.0, sc_td_ms_sm);
        const double amtMid = amt * (1.0 - blend);
        const double amtSide = amt * blend;

        const double mid = (s_l + s_r) * 0.5;
        const double side = (s_l - s_r) * 0.5;

        const double midP = scTdProcessSample(mid, sc_td_fast_mid, sc_td_slow_mid, amtMid);
        const double sideP = scTdProcessSample(side, sc_td_fast_side, sc_td_slow_side, amtSide);

        s_l = midP + sideP;
        s_r = midP - sideP;
    }

    void resetDetectorConditioningState() noexcept
    {
        sc_hp_l.resetState();   sc_hp_r.resetState();
        sc_hp_l_2.resetState(); sc_hp_r_2.resetState();
        sc_lp_l.resetState();   sc_lp_r.resetState();
        sc_lp_l_2.resetState(); sc_lp_r_2.resetState();
        sc_shelf_l.resetState(); sc_shelf_r.resetState();

        sc_td_fast_mid = sc_td_slow_mid = 0.0;
        sc_td_fast_side = sc_td_slow_side = 0.0;
    }

    void processMojoBlock(juce::AudioBuffer<float>& sourceBuf, int nSamp)
    {
        mojo_buf.copyFrom(0, 0, sourceBuf, 0, 0, nSamp);
        mojo_buf.copyFrom(1, 0, sourceBuf, 1, 0, nSamp);

        float* xL = mojo_buf.getWritePointer(0);
        float* xR = mojo_buf.getWritePointer(1);

        const double THRESH_DB = (double)mojo_thresh_sm;
        const double THRESH_DB_DEFAULT = -38.0;
        const double RATIO = 20.0;
        const double ATTACK_MS = 1.5;
        const double RELEASE_MS = 90.0;
        const double UNDERLAY_DB = -10.0;
        const double BASE_DRIVE = 3.0;
        const double ASYM_MIX = 0.35;
        const double BIAS = 0.12;

        const double eps = 1e-12;
        const double underlayGain = dbToLin(UNDERLAY_DB);
        const double extraJuiceDb = juce::jlimit(0.0, 24.0, THRESH_DB_DEFAULT - THRESH_DB);
        const double mojoPreJuice = dbToLin(extraJuiceDb * 0.50);
        const double mojoPostJuice = dbToLin(-extraJuiceDb * 0.50);
        const bool useMojoOS = (mojo_os && mojo_os_stages > 0 && mojo_os_factor > 1);

        const double effRate = useMojoOS ? (s_rate * (double)mojo_os_factor) : s_rate;

        const double atkAlpha = std::exp(-1.0 / ((ATTACK_MS * 0.001) * std::max(effRate, 1.0)));
        const double relAlpha = std::exp(-1.0 / ((RELEASE_MS * 0.001) * std::max(effRate, 1.0)));
        const double slowAlpha = std::exp(-1.0 / (0.050 * std::max(effRate, 1.0)));

        if (!useMojoOS)
        {
            for (int i = 0; i < nSamp; ++i)
            {
                double sL = (double)xL[i] * mojoPreJuice;
                double sR = (double)xR[i] * mojoPreJuice;

                sL = mojo_hp_l.process(sL); sR = mojo_hp_r.process(sR);
                sL = mojo_low_shelf_l.process(sL); sR = mojo_low_shelf_r.process(sR);
                sL = mojo_dip_l.process(sL); sR = mojo_dip_r.process(sR);
                sL = mojo_hi_shelf_l.process(sL); sR = mojo_hi_shelf_r.process(sR);

                const double det = std::max(std::abs(sL), std::abs(sR));
                mojo_scale_sm = smooth1p(mojo_scale_sm, det, slowAlpha);
                const double trans = det / (mojo_scale_sm + eps);

                const double a = (det > mojo_env) ? atkAlpha : relAlpha;
                mojo_env = smooth1p(mojo_env, det, a);

                const double envDb = linToDb(mojo_env + eps);
                const double overDb = envDb - THRESH_DB;
                double grDb = 0.0;
                if (overDb > 0.0) {
                    const double outOverDb = overDb / RATIO;
                    grDb = overDb - outOverDb;
                }
                const double gComp = dbToLin(-grDb);
                sL *= gComp; sR *= gComp;

                const double drive = BASE_DRIVE * (1.0 + 0.35 * juce::jlimit(0.0, 2.0, trans - 1.0));

                const double symL = std::tanh(sL * drive);
                const double symR = std::tanh(sR * drive);
                const double biasTerm = std::tanh(BIAS * drive);
                const double asymL = std::tanh((sL + BIAS) * drive) - biasTerm;
                const double asymR = std::tanh((sR + BIAS) * drive) - biasTerm;

                sL = (1.0 - ASYM_MIX) * symL + ASYM_MIX * asymL;
                sR = (1.0 - ASYM_MIX) * symR + ASYM_MIX * asymR;

                sL = mojo_lp_l.process(sL); sR = mojo_lp_r.process(sR);
                sL *= underlayGain; sR *= underlayGain;
                sL *= mojoPostJuice; sR *= mojoPostJuice;

                double yL = sL - mojo_dc_x1_l + 0.995 * mojo_dc_y1_l;
                mojo_dc_x1_l = sL; mojo_dc_y1_l = yL;
                double yR = sR - mojo_dc_x1_r + 0.995 * mojo_dc_y1_r;
                mojo_dc_x1_r = sR; mojo_dc_y1_r = yR;

                xL[i] = (float)yL; xR[i] = (float)yR;
            }
            return;
        }

        auto baseBlock = juce::dsp::AudioBlock<float>(mojo_buf).getSubBlock(0, (size_t)nSamp);
        auto osBlock = mojo_os->processSamplesUp(baseBlock);

        float* dL = osBlock.getChannelPointer(0);
        float* dR = osBlock.getChannelPointer(1);
        const int osN = (int)osBlock.getNumSamples();

        for (int j = 0; j < osN; ++j)
        {
            double sL = (double)dL[j] * mojoPreJuice;
            double sR = (double)dR[j] * mojoPreJuice;

            sL = mojo_hp_l.process(sL); sR = mojo_hp_r.process(sR);
            sL = mojo_low_shelf_l.process(sL); sR = mojo_low_shelf_r.process(sR);
            sL = mojo_dip_l.process(sL); sR = mojo_dip_r.process(sR);
            sL = mojo_hi_shelf_l.process(sL); sR = mojo_hi_shelf_r.process(sR);

            const double det = std::max(std::abs(sL), std::abs(sR));
            mojo_scale_sm = smooth1p(mojo_scale_sm, det, slowAlpha);
            const double trans = det / (mojo_scale_sm + eps);

            const double a = (det > mojo_env) ? atkAlpha : relAlpha;
            mojo_env = smooth1p(mojo_env, det, a);

            const double envDb = linToDb(mojo_env + eps);
            const double overDb = envDb - THRESH_DB;
            double grDb = 0.0;
            if (overDb > 0.0) {
                const double outOverDb = overDb / RATIO;
                grDb = overDb - outOverDb;
            }
            const double gComp = dbToLin(-grDb);
            sL *= gComp; sR *= gComp;

            const double drive = BASE_DRIVE * (1.0 + 0.35 * juce::jlimit(0.0, 2.0, trans - 1.0));

            const double symL = std::tanh(sL * drive);
            const double symR = std::tanh(sR * drive);

            const double biasTerm = std::tanh(BIAS * drive);
            const double asymL = std::tanh((sL + BIAS) * drive) - biasTerm;
            const double asymR = std::tanh((sR + BIAS) * drive) - biasTerm;

            sL = (1.0 - ASYM_MIX) * symL + ASYM_MIX * asymL;
            sR = (1.0 - ASYM_MIX) * symR + ASYM_MIX * asymR;

            dL[j] = (float)sL;
            dR[j] = (float)sR;
        }

        mojo_os->processSamplesDown(baseBlock);

        for (int i = 0; i < nSamp; ++i)
        {
            double sL = (double)xL[i];
            double sR = (double)xR[i];

            sL = mojo_lp_l.process(sL); sR = mojo_lp_r.process(sR);
            sL *= underlayGain; sR *= underlayGain;

            double yL = sL - mojo_dc_x1_l + 0.995 * mojo_dc_y1_l;
            mojo_dc_x1_l = sL; mojo_dc_y1_l = yL;
            double yR = sR - mojo_dc_x1_r + 0.995 * mojo_dc_y1_r;
            mojo_dc_x1_r = sR; mojo_dc_y1_r = yR;

            xL[i] = (float)yL; xR[i] = (float)yR;
        }
    }


    void processCompressorBlock(juce::AudioBuffer<float>& io)
    {
        const int nSamp = io.getNumSamples();
        float* l = io.getWritePointer(0);
        float* r = io.getWritePointer(1);
        float* sc_l = sc_internal_buf.getWritePointer(0);
        float* sc_r = sc_internal_buf.getWritePointer(1);

        if (!p_active_dyn)
        {
            det_env = 0.0; env = 0.0;
            env_l = env_r = 0.0;
            env_fast = env_slow = 0.0;
            env_fast_l = env_fast_r = 0.0;
            env_slow_l = env_slow_r = 0.0;
            fb_prev_l = fb_prev_r = 0.0;
            return;
        }

        const double thresh_target = (double)p_thresh;
        const double ratio_target = std::max(1.0, (double)p_ratio);
        const double knee_target = std::max(0.0, (double)p_knee);

        double sum_in_rms = 0.0;
        double sum_out_rms = 0.0;

        for (int i = 0; i < nSamp; ++i)
        {
            thresh_sm = smooth1p(thresh_sm, thresh_target, smooth_alpha);
            ratio_sm = smooth1p(ratio_sm, ratio_target, smooth_alpha);
            knee_sm = smooth1p(knee_sm, knee_target, smooth_alpha);

            comp_in_sm = smooth1p(comp_in_sm, comp_in_target, smooth_alpha);
            makeup_lin_sm = smooth1p(makeup_lin_sm, makeup_lin_target, smooth_alpha);
            sc_level_sm = smooth1p(sc_level_sm, sc_level_target, smooth_alpha);
            sc_td_amt_sm = smooth1p(sc_td_amt_sm, sc_td_amt_target, smooth_alpha);
            sc_td_ms_sm = smooth1p(sc_td_ms_sm, sc_td_ms_target, smooth_alpha);
            ms_bal_sm = smooth1p(ms_bal_sm, ms_bal_target, smooth_alpha);

            double in_gain = comp_in_sm;
            l[i] *= (float)in_gain;
            r[i] *= (float)in_gain;

            if (p_comp_autogain_mode > 0) {
                sum_in_rms += (double)l[i] * (double)l[i] + (double)r[i] * (double)r[i];
            }

            double s_l = (double)sc_l[i];
            double s_r = (double)sc_r[i];

            if (p_sc_input_mode == 0) {
                s_l *= in_gain;
                s_r *= in_gain;
            }

            if (!p_sc_to_comp) {
                s_l = (double)l[i];
                s_r = (double)r[i];
            }
            else {
                s_l *= sc_level_sm;
                s_r *= sc_level_sm;

                if (p_active_det) {
                    s_l = sc_hp_l_2.process(sc_hp_l.process(s_l));
                    s_r = sc_hp_r_2.process(sc_hp_r.process(s_r));
                    s_l = sc_lp_l_2.process(sc_lp_l.process(s_l));
                    s_r = sc_lp_r_2.process(sc_lp_r.process(s_r));
                    if (p_thrust_mode > 0) {
                        s_l = sc_shelf_l.process(s_l);
                        s_r = sc_shelf_r.process(s_r);
                    }
                }
            }

            if (p_sc_to_comp && p_active_det)
                applySidechainTransientDesigner(s_l, s_r);

            double det_in_l = s_l;
            double det_in_r = s_r;

            if (p_ms_mode > 0) {
                double mid = (s_l + s_r) * 0.5;
                double side = (s_l - s_r) * 0.5;
                if (p_ms_mode == 1) { det_in_l = mid; det_in_r = mid; }
                else if (p_ms_mode == 2) { det_in_l = side; det_in_r = side; }
                else if (p_ms_mode == 3) { det_in_l = mid; det_in_r = mid; }
                else if (p_ms_mode == 4) { det_in_l = side; det_in_r = side; }
            }

            det_in_l = det_in_l * (1.0 - fb_blend) + fb_prev_l * fb_blend;
            det_in_r = det_in_r * (1.0 - fb_blend) + fb_prev_r * fb_blend;
            runDetector(det_in_l, det_in_r);

            const double lin_gain_l = std::pow(10.0, env_l / 20.0);
            const double lin_gain_r = std::pow(10.0, env_r / 20.0);
            const double lin_gain_mono = std::pow(10.0, env / 20.0);

            double pre_make_l = 0.0;
            double pre_make_r = 0.0;

            double in_l = (double)l[i];
            double in_r = (double)r[i];

            if (p_ms_mode == 0) {
                pre_make_l = in_l * lin_gain_l;
                pre_make_r = in_r * lin_gain_r;
            }
            else {
                double mid = (in_l + in_r) * 0.5;
                double side = (in_l - in_r) * 0.5;
                if (p_ms_mode == 1) mid *= lin_gain_mono;
                else if (p_ms_mode == 2) side *= lin_gain_mono;
                else if (p_ms_mode == 3) side *= lin_gain_mono;
                else if (p_ms_mode == 4) mid *= lin_gain_mono;

                if (p_ms_mode == 3) { mid *= (1.0 / std::max(1e-6, ms_bal_sm)); side *= ms_bal_sm; }
                else if (p_ms_mode == 4) { mid *= ms_bal_sm; side *= (1.0 / std::max(1e-6, ms_bal_sm)); }
                pre_make_l = mid + side;
                pre_make_r = mid - side;
            }

            fb_prev_l = pre_make_l;
            fb_prev_r = pre_make_r;

            if (p_comp_autogain_mode > 0) {
                sum_out_rms += pre_make_l * pre_make_l + pre_make_r * pre_make_r;
            }

            const double final_agc = (double)comp_agc_gain_sm;
            const double mirror = (p_comp_mirror) ? (1.0 / std::max(1e-6, comp_in_sm)) : 1.0;
            l[i] = (float)(pre_make_l * makeup_lin_sm * final_agc * mirror);
            r[i] = (float)(pre_make_r * makeup_lin_sm * final_agc * mirror);
        }

        if (p_comp_autogain_mode > 0 && sum_in_rms > 1e-12) {
            double rms_in = std::sqrt(sum_in_rms / (double)(nSamp * 2));
            double rms_out = std::sqrt(sum_out_rms / (double)(nSamp * 2));

            if (rms_in > 0.001) {
                double g_req = rms_in / (rms_out + 1e-24);
                g_req = juce::jlimit(0.25, 4.0, g_req);

                double strength = (p_comp_autogain_mode == 1) ? 0.5 : 1.0;
                double g_target = std::pow(g_req, strength);

                double agc_alpha = std::exp(-(double)nSamp / (0.300 * s_rate));
                comp_agc_gain_sm = comp_agc_gain_sm * agc_alpha + g_target * (1.0 - agc_alpha);
            }
        }
        else if (p_comp_autogain_mode == 0) {
            double agc_alpha = std::exp(-(double)nSamp / (0.100 * s_rate));
            comp_agc_gain_sm = comp_agc_gain_sm * agc_alpha + 1.0 * (1.0 - agc_alpha);
        }
    }

    void processAuditionBlock(juce::AudioBuffer<float>& buf)
    {
        const int nSamp = buf.getNumSamples();
        auto* l = buf.getWritePointer(0);
        auto* r = buf.getNumChannels() > 1 ? buf.getWritePointer(1) : nullptr;

        for (int i = 0; i < nSamp; ++i)
        {
            comp_in_sm = smooth1p(comp_in_sm, comp_in_target, smooth_alpha);
            sc_level_sm = smooth1p(sc_level_sm, sc_level_target, smooth_alpha);
            sc_td_amt_sm = smooth1p(sc_td_amt_sm, sc_td_amt_target, smooth_alpha);
            sc_td_ms_sm = smooth1p(sc_td_ms_sm, sc_td_ms_target, smooth_alpha);

            double s_l = (double)sc_internal_buf.getSample(0, i);
            double s_r = (double)((sc_internal_buf.getNumChannels() > 1) ? sc_internal_buf.getSample(1, i) : sc_internal_buf.getSample(0, i));

            if (!p_sc_to_comp)
            {
                s_l = (double)l[i];
                s_r = (double)(r ? r[i] : l[i]);
            }
            else
            {
                s_l *= sc_level_sm;
                s_r *= sc_level_sm;

                if (p_sc_input_mode == 0)
                {
                    s_l *= comp_in_sm;
                    s_r *= comp_in_sm;
                }

                if (p_active_det)
                {
                    s_l = sc_hp_l_2.process(sc_hp_l.process(s_l));
                    s_r = sc_hp_r_2.process(sc_hp_r.process(s_r));
                    s_l = sc_lp_l_2.process(sc_lp_l.process(s_l));
                    s_r = sc_lp_r_2.process(sc_lp_r.process(s_r));

                    if (p_thrust_mode != 0) {
                        s_l = sc_shelf_l.process(s_l);
                        s_r = sc_shelf_r.process(s_r);
                    }
                }

                if (p_active_det)
                    applySidechainTransientDesigner(s_l, s_r);

            }

            double det_in_l = s_l;
            double det_in_r = s_r;

            if (p_ms_mode > 0)
            {
                const double mid = (s_l + s_r) * 0.5;
                const double side = (s_l - s_r) * 0.5;

                if (p_ms_mode == 1) { det_in_l = det_in_r = mid; }
                else if (p_ms_mode == 2) { det_in_l = det_in_r = side; }
                else if (p_ms_mode == 3) { det_in_l = det_in_r = mid; }
                else if (p_ms_mode == 4) { det_in_l = det_in_r = side; }
            }

            l[i] = (float)det_in_l;
            if (r) r[i] = (float)det_in_r;
        }
    }

    void runDetector(double s_l, double s_r)
    {
        double det_l_raw = 0.0, det_r_raw = 0.0;

        if (use_rms) {
            const double pL = s_l * s_l;
            const double pR = s_r * s_r;

            rms_sum_l += pL - rms_ring_l[(size_t)rms_pos];
            rms_sum_r += pR - rms_ring_r[(size_t)rms_pos];

            rms_ring_l[(size_t)rms_pos] = pL;
            rms_ring_r[(size_t)rms_pos] = pR;

            rms_pos++; if (rms_pos >= rms_window) rms_pos = 0;

            det_l_raw = std::sqrt(std::max(0.0, rms_sum_l / (double)rms_window));
            det_r_raw = std::sqrt(std::max(0.0, rms_sum_r / (double)rms_window));
        }
        else {
            det_l_raw = std::abs(s_l);
            det_r_raw = std::abs(s_r);
        }

        const double det_avg = std::sqrt(0.5 * (det_l_raw * det_l_raw + det_r_raw * det_r_raw));
        const double det_max = std::max(det_l_raw, det_r_raw);
        const double det = det_max;

        double eff_thresh_db = thresh_sm;
        if (p_active_tf && tp_enabled)
        {
            const double pk = det_max;
            const double det_fast = (pk > det_env)
                ? (att_coeff * det_env + (1.0 - att_coeff) * pk)
                : (auto_rel_fast * det_env + (1.0 - auto_rel_fast) * pk);
            det_env = det_fast;

            const double tp_metric = juce::jlimit(0.0, 1.0, (linToDb(det_env + 1e-20) - linToDb(det_avg + 1e-20)) / 24.0);
            const double tp_boost = tp_metric * tp_amt * tp_raise_db;
            eff_thresh_db += tp_boost;
        }
        else {
            if (!p_active_tf) det_env = 0.0;
        }

        double eff_ratio = ratio_sm;
        if (p_active_tf && p_ctrl_mode == 1)
        {
            const double crest_coeff_local = crest_coeff;
            cf_peak_env = std::max(det_max, cf_peak_env * crest_coeff_local);
            const double rms_p = det_avg * det_avg;
            cf_rms_sum = smooth1p(cf_rms_sum, rms_p, crest_coeff_local);
            const double rms = std::sqrt(std::max(0.0, cf_rms_sum));
            const double crest = linToDb((cf_peak_env + 1e-20) / (rms + 1e-20));

            const double err = crest - crest_target_db;
            const double cf_step = (1.0 - crest_coeff_local) * 0.002;
            cf_amt = juce::jlimit(0.0, 1.0, cf_amt + err * cf_step);

            eff_ratio = ratio_sm * (1.0 + cf_amt * 2.0);
            eff_thresh_db -= cf_amt * 3.0;
        }
        else {
            cf_amt = 0.0;
        }

        if (p_active_tf && flux_enabled)
        {
            const double drive = sat_drive_lin_sm;
            const double meas_pk = det_max * drive;
            const double meas_db = linToDb(meas_pk + 1e-20);
            const double metric = juce::jlimit(0.0, 1.0, (meas_db - (-24.0)) / 24.0);
            flux_env = std::max(metric, flux_env * 0.995);
            eff_thresh_db += flux_env * (6.0 * flux_amt);
        }
        else {
            if (!p_active_tf) flux_env = 0.0;
        }

        auto compute_gr_db = [&](double det_db) -> double
            {
                const double knee = knee_sm;
                double gr_db = 0.0;

                if (knee > 0.0) {
                    const double x = det_db - eff_thresh_db;
                    const double half = knee * 0.5;
                    if (x <= -half) gr_db = 0.0;
                    else if (x >= half) gr_db = -(x - x / eff_ratio);
                    else {
                        const double t = (x + half) / knee;
                        const double y = t * t * (3.0 - 2.0 * t);
                        const double x2 = x - (-half);
                        const double gr_full = -(x2 - x2 / eff_ratio);
                        gr_db = gr_full * y;
                    }
                }
                else {
                    const double x = det_db - eff_thresh_db;
                    gr_db = (x > 0.0) ? -(x - x / eff_ratio) : 0.0;
                }

                return gr_db;
            };

        if (p_ms_mode == 0)
        {
            const double link = stereo_link;

            const double det_db_l = linToDb(det_l_raw + 1e-20);
            const double det_db_r = linToDb(det_r_raw + 1e-20);
            const double det_db_link = linToDb(det_max + 1e-20);

            const double gr_l_un = compute_gr_db(det_db_l);
            const double gr_r_un = compute_gr_db(det_db_r);
            const double gr_link = compute_gr_db(det_db_link);

            const double target_l = gr_l_un + (gr_link - gr_l_un) * link;
            const double target_r = gr_r_un + (gr_link - gr_r_un) * link;

            auto updateEnv = [&](double target, double& envC, double& fastC, double& slowC)
                {
                    if (target < envC) {
                        envC = att_coeff * envC + (1.0 - att_coeff) * target;
                        fastC = envC;
                        slowC = envC;
                        rel_coeff = att_coeff;
                    }
                    else {
                        if (p_auto_rel) {
                            fastC = auto_rel_fast * fastC + (1.0 - auto_rel_fast) * target;
                            slowC = auto_rel_slow * slowC + (1.0 - auto_rel_slow) * target;
                            envC = std::min(fastC, slowC);
                        }
                        else {
                            envC = rel_coeff_manual * envC + (1.0 - rel_coeff_manual) * target;
                            fastC = envC;
                            slowC = envC;
                            rel_coeff = rel_coeff_manual;
                        }
                    }
                };

            updateEnv(target_l, env_l, env_fast_l, env_slow_l);
            updateEnv(target_r, env_r, env_fast_r, env_slow_r);

            env = 0.5 * (env_l + env_r);
            env_fast = 0.5 * (env_fast_l + env_fast_r);
            env_slow = 0.5 * (env_slow_l + env_slow_r);
        }
        else
        {
            const double det_db = linToDb(det + 1e-20);
            const double gr_db = compute_gr_db(det_db);

            const double target = gr_db;
            if (target < env) {
                env = att_coeff * env + (1.0 - att_coeff) * target;
                env_fast = env;
                env_slow = env;
                rel_coeff = att_coeff;
            }
            else {
                if (p_auto_rel) {
                    env_fast = auto_rel_fast * env_fast + (1.0 - auto_rel_fast) * target;
                    env_slow = auto_rel_slow * env_slow + (1.0 - auto_rel_slow) * target;
                    env = std::min(env_fast, env_slow);
                }
                else {
                    env = rel_coeff_manual * env + (1.0 - rel_coeff_manual) * target;
                    env_fast = env;
                    env_slow = env;
                    rel_coeff = rel_coeff_manual;
                }
            }
        }
    }


    void processSaturationBlock(juce::AudioBuffer<float>& io, int nSamp)
    {
        if (!p_active_sat && !p_active_eq) return;

        const int nCh = io.getNumChannels();

        if (!p_active_sat && p_active_eq)
        {
            for (int ch = 0; ch < nCh; ++ch)
            {
                sat_clean_buf.copyFrom(ch, 0, io, ch, 0, nSamp);
                sat_proc_buf.copyFrom(ch, 0, io, ch, 0, nSamp);
            }

            const bool eq_tone_active = (std::abs(p_sat_tone) > 0.01f);
            const bool eq_girth_active = (std::abs(p_girth) > 0.01f);

            for (int ch = 0; ch < nCh; ++ch)
            {
                float* y = sat_proc_buf.getWritePointer(ch);
                auto& tone = (ch == 0) ? sat_tone_l : sat_tone_r;
                auto& gBump = (ch == 0) ? girth_bump_l : girth_bump_r;
                auto& gDip = (ch == 0) ? girth_dip_l : girth_dip_r;

                for (int i = 0; i < nSamp; ++i)
                {
                    double s = (double)y[i];
                    if (eq_girth_active) { s = gBump.process(s); s = gDip.process(s); }
                    if (eq_tone_active) { s = tone.process(s); }
                    y[i] = (float)s;
                }
            }

            sat_mix_sm = smooth1p(sat_mix_sm, sat_mix_target, smooth_alpha_block);
            const float satMix01 = (float)juce::jlimit(0.0, 1.0, sat_mix_sm);

            for (int ch = 0; ch < nCh; ++ch)
            {
                float* out = io.getWritePointer(ch);
                const float* wet = sat_proc_buf.getReadPointer(ch);
                const float* dry = sat_clean_buf.getReadPointer(ch);

                for (int i = 0; i < nSamp; ++i)
                    out[i] = dry[i] + (wet[i] - dry[i]) * satMix01;
            }

            return;
        }

        if (!os) return;

        for (int ch = 0; ch < nCh; ++ch)
            sat_clean_buf.copyFrom(ch, 0, io, ch, 0, nSamp);

        if (p_active_sat) {
            auto block = juce::dsp::AudioBlock<float>(sat_clean_buf).getSubBlock(0, (size_t)nSamp);
            juce::dsp::ProcessContextReplacing<float> context(block);
            satInternalDelay.process(context);
        }

        for (int ch = 0; ch < nCh; ++ch)
            sat_proc_buf.copyFrom(ch, 0, io, ch, 0, nSamp);

        sat_pre_lin_sm = smooth1p(sat_pre_lin_sm, sat_pre_lin_target, smooth_alpha_block);
        sat_drive_lin_sm = smooth1p(sat_drive_lin_sm, sat_drive_lin_target, smooth_alpha_block);

        const float pre_gain = (float)sat_pre_lin_sm;
        if (p_active_sat) {
            for (int ch = 0; ch < nCh; ++ch) {
                float* x = sat_proc_buf.getWritePointer(ch);
                for (int i = 0; i < nSamp; ++i) x[i] *= pre_gain;
            }
        }

        auto block = juce::dsp::AudioBlock<float>(sat_proc_buf).getSubBlock(0, (size_t)nSamp);
        auto osBlock = os->processSamplesUp(block);

        const int mode = p_sat_mode;
        const double drive = (double)sat_drive_lin_sm;
        const int osN = (int)osBlock.getNumSamples();
        const bool eq_tone_active = p_active_eq && (std::abs(p_sat_tone) > 0.01f);
        const bool eq_bright_active = p_active_eq && (std::abs(p_harm_bright) > 0.01f);
        const bool eq_girth_active = p_active_eq && (std::abs(p_girth) > 0.01f);

        for (int ch = 0; ch < nCh; ++ch)
        {
            float* data = osBlock.getChannelPointer(ch);
            auto& pre = (ch == 0) ? harm_pre_l : harm_pre_r;
            auto& post = (ch == 0) ? harm_post_l : harm_post_r;
            double& phi = (ch == 0) ? steel_phi_l : steel_phi_r;
            double& yPrev = (ch == 0) ? steel_prev_x_l : steel_prev_x_r;

            for (int i = 0; i < osN; ++i)
            {
                double s = (double)data[i];
                if (eq_bright_active) s = pre.process(s);

                if (p_active_sat) {
                    s *= drive;
                    if (mode == 1) {
                        const double bias = 0.075;
                        const double y0 = std::tanh(bias);
                        const double y = std::tanh(s + bias) - y0;
                        const double s_sat = std::tanh(s);
                        const double poly = s_sat - (s_sat * s_sat * s_sat) * 0.333333333333;
                        s = 0.82 * y + 0.18 * poly;
                    }
                    else if (mode == 2) {
                        phi = phi * steel_leak_coeff + s * steel_dt;
                        const double y = std::tanh(phi * 7.0);
                        double dy = (y - yPrev) * steel_dy_gain;
                        yPrev = y;
                        dy = std::tanh(dy * 0.85);
                        const double base = std::tanh(s * 1.05);
                        s = 0.65 * dy + 0.35 * base;
                    }
                }

                if (eq_bright_active) s = post.process(s);
                data[i] = (float)s;
            }
        }
        os->processSamplesDown(block);

        const double mirror_comp = (p_sat_mirror) ? (1.0 / std::max(1e-6, (double)pre_gain)) : 1.0;

        if (p_active_sat && p_sat_mirror) {
            for (int ch = 0; ch < nCh; ++ch) {
                float* y = sat_proc_buf.getWritePointer(ch);
                for (int i = 0; i < nSamp; ++i) y[i] *= (float)mirror_comp;
            }
        }

        const bool sat_agc_active = (p_active_sat && (p_sat_autogain_mode != 0));
        double outPow_post = 0.0;

        for (int ch = 0; ch < nCh; ++ch)
        {
            float* y = sat_proc_buf.getWritePointer(ch);
            auto& ironV = (ch == 0) ? iron_voicing_l : iron_voicing_r;
            auto& stLo = (ch == 0) ? steel_low_l : steel_low_r;
            auto& stHi = (ch == 0) ? steel_high_l : steel_high_r;
            auto& tone = (ch == 0) ? sat_tone_l : sat_tone_r;
            auto& gBump = (ch == 0) ? girth_bump_l : girth_bump_r;
            auto& gDip = (ch == 0) ? girth_dip_l : girth_dip_r;

            for (int i = 0; i < nSamp; ++i)
            {
                double s = (double)y[i];

                if (p_active_sat && (mode == 1 || mode == 2)) {
                    if (mode == 1) s = ironV.process(s);
                    else { s = stLo.process(s); s = stHi.process(s); }
                }

                if (eq_girth_active) { s = gBump.process(s); s = gDip.process(s); }
                if (eq_tone_active)  s = tone.process(s);

                y[i] = (float)s;

                if (sat_agc_active) outPow_post += s * s;
            }
        }

        {
            const double alpha = std::exp(-(double)nSamp / (0.300 * s_rate));

            if (sat_agc_active)
            {
                double inPow = 0.0;
                for (int ch = 0; ch < nCh; ++ch) {
                    const float* x = sat_clean_buf.getReadPointer(ch);
                    for (int i = 0; i < nSamp; ++i) inPow += (double)x[i] * (double)x[i];
                }

                if (inPow > 1e-20 && outPow_post > 1e-20) {
                    double g = std::sqrt(inPow / outPow_post);
                    g = juce::jlimit(0.125, 8.0, g);
                    const double exponent = (p_sat_autogain_mode == 1) ? 0.5 : 1.0;
                    const double gTarget = std::pow(g, exponent);
                    sat_agc_gain_sm = sat_agc_gain_sm * alpha + gTarget * (1.0 - alpha);

                    const float gSm = (float)sat_agc_gain_sm;
                    for (int ch = 0; ch < nCh; ++ch) {
                        float* y = sat_proc_buf.getWritePointer(ch);
                        for (int i = 0; i < nSamp; ++i) y[i] *= gSm;
                    }
                }
            }
            else
            {
                sat_agc_gain_sm = sat_agc_gain_sm * alpha + 1.0 * (1.0 - alpha);
            }
        }

        sat_trim_lin_sm = smooth1p(sat_trim_lin_sm, sat_trim_lin, smooth_alpha_block);
        const double trim = (double)sat_trim_lin_sm;

        if (p_active_sat)
        {
            for (int ch = 0; ch < nCh; ++ch) {
                float* y = sat_proc_buf.getWritePointer(ch);
                for (int i = 0; i < nSamp; ++i) y[i] *= (float)trim;
            }
        }

        sat_mix_sm = smooth1p(sat_mix_sm, sat_mix_target, smooth_alpha_block);
        const float satMix01 = (float)juce::jlimit(0.0, 1.0, sat_mix_sm);

        if (p_active_sat || p_active_eq)
        {
            for (int ch = 0; ch < nCh; ++ch) {
                float* finalOut = io.getWritePointer(ch);
                const float* wet = sat_proc_buf.getReadPointer(ch);
                const float* dry = sat_clean_buf.getReadPointer(ch);
                for (int i = 0; i < nSamp; ++i) {
                    finalOut[i] = dry[i] + (wet[i] - dry[i]) * satMix01;
                }
            }
        }
    }

    double s_rate = 48000.0;
    int max_block = 512;
    int os_latency_samples = 0;

    std::unique_ptr<juce::dsp::Oversampling<float>> os;

    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> dryDelayLine{ 8192 };
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> wetDelayLine{ 8192 };

    std::unique_ptr<juce::dsp::Oversampling<float>> mojo_os;
    int mojo_os_stages = 0;
    int mojo_os_factor = 1;

    int os_stages = 2;
    int os_factor = 4;
    double os_srate = 176400.0;

    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Thiran> satInternalDelay{ 8192 };

    SimpleBiquad sc_hp_l, sc_hp_r, sc_hp_l_2, sc_hp_r_2;
    SimpleBiquad sc_lp_l, sc_lp_r, sc_lp_l_2, sc_lp_r_2;
    SimpleBiquad sc_shelf_l, sc_shelf_r;
    SimpleBiquad sat_tone_l, sat_tone_r;
    SimpleBiquad girth_bump_l, girth_bump_r, girth_dip_l, girth_dip_r;
    SimpleBiquad harm_pre_l, harm_pre_r, harm_post_l, harm_post_r;
    SimpleBiquad iron_voicing_l, iron_voicing_r, steel_low_l, steel_low_r, steel_high_l, steel_high_r;

    double fb_prev_l = 0.0, fb_prev_r = 0.0;
    double det_env = 0.0, env = 0.0;
    double env_l = 0.0, env_r = 0.0;
    double env_fast = 0.0, env_slow = 0.0;
    double env_fast_l = 0.0, env_fast_r = 0.0;
    double env_slow_l = 0.0, env_slow_r = 0.0;
    double att_coeff = 0.999, rel_coeff_manual = 0.999, rel_coeff = 0.999, auto_rel_slow = 0.999, auto_rel_fast = 0.90;

    bool use_rms = false;
    int rms_window = 1;
    int rms_window_max = 1;
    std::vector<double> rms_ring_l;
    std::vector<double> rms_ring_r;
    int rms_pos = 0;
    double rms_sum_l = 0.0, rms_sum_r = 0.0;
    double stereo_link = 1.0;
    double fb_blend = 0.0;

    double crest_target_db = 12.0;
    double crest_speed_ms = 400.0;
    double crest_coeff = 0.999;
    double cf_peak_env = 0.0;
    double cf_rms_sum = 0.0;
    double cf_amt = 0.0;
    double cf_ratio_mix = 0.0;

    bool tp_enabled = false;
    double tp_amt = 0.5;
    double tp_raise_db = 12.0;
    bool flux_enabled = false;
    double flux_amt = 0.3;
    double flux_env = 0.0;

    double steel_phi_l = 0.0, steel_phi_r = 0.0;
    double steel_prev_x_l = 0.0, steel_prev_x_r = 0.0;
    double steel_dt = 0.0, steel_dy_gain = 1.0, steel_leak_coeff = 1.0;

    double sat_agc_gain_sm = 1.0;
    double comp_agc_gain_sm = 1.0;
    double global_in_sm = 1.0, global_in_target = 1.0;

    double thrust_gain_db = 0.0;

    double makeup_lin_target = 1.0, makeup_lin_sm = 1.0;
    double comp_in_target = 1.0, comp_in_sm = 1.0;
    double sc_level_target = 1.0, sc_level_sm = 1.0;
    double ms_bal_target = 1.0, ms_bal_sm = 1.0;

    double sc_td_amt_target = 0.0, sc_td_amt_sm = 0.0;
    double sc_td_ms_target = 0.0, sc_td_ms_sm = 0.0;

    double sc_td_fast_att = 0.999, sc_td_fast_rel = 0.999;
    double sc_td_slow_att = 0.999, sc_td_slow_rel = 0.999;

    double sc_td_fast_mid = 0.0, sc_td_slow_mid = 0.0;
    double sc_td_fast_side = 0.0, sc_td_slow_side = 0.0;

    double out_lin_target = 1.0, out_lin_sm = 1.0;
    double sat_pre_lin_target = 1.0, sat_pre_lin_sm = 1.0;
    double sat_drive_lin_target = 1.0, sat_drive_lin_sm = 1.0;
    double sat_trim_lin = 1.0, sat_trim_lin_sm = 1.0;
    double sat_mix_target = 1.0, sat_mix_sm = 1.0;
    double drywet_sm = 1.0;

    double smooth_alpha = 0.999, smooth_alpha_block = 0.999, smooth_alpha_os = 0.999;
    double thresh_sm = -20.0, ratio_sm = 4.0, knee_sm = 6.0;

    int last_sat_mode = -1;
    int last_ctrl_mode = -1;

    double topologyRamp = 1.0;
    double topologyInc = 0.0;

    bool prevTopoSatEq = false;
    int  prevTopoFlow = 0;
    bool prevTopoAudition = false;
    int  prevTopoMsMode = 0;
    int  prevTopoScMode = 0;
    bool prevTopoScToComp = false;

    double mojo_on_sm = 0.0;
    bool   mojo_prev_on = false;
    double mojo_scale_sm = 1.0;
    double mojo_mix_sm = 0.5;
    double mojo_mix_target = 0.5;
    double mojo_env = 0.0;
    double mojo_level_sm = 1.0;
    double mojo_thresh_sm = -38.0;

    SimpleBiquad mojo_hp_l, mojo_hp_r;
    SimpleBiquad mojo_low_shelf_l, mojo_low_shelf_r;
    SimpleBiquad mojo_dip_l, mojo_dip_r;
    SimpleBiquad mojo_hi_shelf_l, mojo_hi_shelf_r;
    SimpleBiquad mojo_lp_l, mojo_lp_r;

    double mojo_dc_x1_l = 0.0, mojo_dc_y1_l = 0.0;
    double mojo_dc_x1_r = 0.0, mojo_dc_y1_r = 0.0;

    float c_att_ms = -1.f, c_rel_ms = -1.f;
    bool c_turbo_att = false, c_turbo_rel = false;
    float c_det_rms = -1.f;
    float c_sc_hp_freq = -1.f, c_sc_lp_freq = -1.f;
    int c_thrust_mode = -1;
    float c_crest_speed = -1.f;
    float c_sat_tone = -100.f, c_sat_tone_freq = -1.f;
    float c_girth = -100.f; int c_girth_freq_sel = -1;
    float c_harm_bright = -100.f, c_harm_freq = -1.f;
    double c_s_rate = -1.0;

    juce::AudioBuffer<float> dry_buf, wet_buf, sc_internal_buf, mojo_buf;
    juce::AudioBuffer<float> sat_clean_buf, sat_proc_buf;
};